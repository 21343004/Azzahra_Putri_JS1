for (let a = 20; a <= 40; a += 2) {
    console.log(a);
  }
  