let nilai = 75;

if (nilai >= 90) {
  console.log("Nilai Anda A");
} else if (nilai >= 80) {
  console.log("Nilai Anda B");
} else if (nilai >= 70) {
  console.log("Nilai Anda C");
} else if (nilai >= 60) {
  console.log("Nilai Anda D");
} else {
  console.log("Nilai Anda E");
}
