let pesan = ["Selamat pagi!", "Selamat siang!", "Selamat sore!", "Selamat malam!", "Halo, dunia!"];
let i = 0;

while (i < pesan.length) {
  console.log(pesan[i]);
  i++;
}

i = 0;

do {
  console.log(pesan[i]);
  i++;
} while (i < pesan.length);



