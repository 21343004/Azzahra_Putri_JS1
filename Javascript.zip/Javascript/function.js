
function tambah(a, b) {
   
    const hasilPenjumlahan = a + b;
    return hasilPenjumlahan;
  }
     const hasil = tambah(12, 3);
  

  console.log(`Hasil penjumlahan: ${hasil}`);
  
  
  